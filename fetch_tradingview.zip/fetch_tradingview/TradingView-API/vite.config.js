module.exports = {
  test: {
    testTimeout: 10000,
    retry: 3,
    setupFiles: 'dotenv/config',
  },
};
